const express = require('express');
const app = express();
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const session = require('express-session');

// --- DB ---
const db = new sqlite3.Database('./db/discoverhealth.db', (err) => {
  if (err) console.error('❌ Error opening database:', err);
  else console.log('✅ Connected to the DiscoverHealth database.');
});

// Create reviews table (rating + comment) once
db.serialize(() => {
  db.run('PRAGMA foreign_keys = ON');
  db.run(`
    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      resource_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
      comment TEXT NOT NULL CHECK(length(comment) <= 500),
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(resource_id) REFERENCES healthcare_resources(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);
});

// --- Middlewares ---
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'mySecretKey',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', path: '/' }
}));

function requireLogin(req, res, next) {
  if (req.session && req.session.user) return next();
  return res.status(401).json({ error: 'Login required' });
}

// --- Pages ---
app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- Auth ---
app.post('/api/register', (req, res) => {
  const { username = '', password = '' } = req.body;
  if (!username.trim() || !password.trim()) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  db.get('SELECT 1 FROM users WHERE username = ?', [username], (err, exists) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (exists) return res.status(400).json({ error: 'Username already exists' });

    db.run('INSERT INTO users (username, password, isAdmin) VALUES (?, ?, 0)',
      [username, password],
      function (err2) {
        if (err2) return res.status(500).json({ error: 'Registration failed' });
        return res.status(201).json({ message: 'User registered successfully' });
      });
  });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ? AND password = ?',
    [username, password],
    (err, user) => {
      if (err)   return res.status(500).json({ message: 'Database error' });
      if (!user) return res.status(401).json({ success: false, message: 'Invalid username or password' });
      req.session.user = { id: user.id, username: user.username, isAdmin: user.isAdmin };
      return res.json({ success: true, message: 'Login successful!' });
    });
});

app.get('/api/session', (req, res) => {
  if (req.session?.user) return res.json({ username: req.session.user.username, isAdmin: req.session.user.isAdmin });
  return res.json({ username: null });
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid', { path: '/' });
    res.redirect('/index.html');
  });
});

// --- Resources ---
app.get('/api/resources', (req, res) => {
  const region = (req.query.region || '').trim();
  if (!region) return res.status(400).json({ error: 'Region is required' });

  db.all('SELECT * FROM healthcare_resources WHERE region = ?', [region], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    return res.json(rows);
  });
});

app.post('/api/resources', requireLogin, (req, res) => {
  const fields = ['name','category','country','region','lat','lon','description'];
  const missing = fields.filter(f => !req.body || !String(req.body[f] ?? '').trim());
  if (missing.length) return res.status(400).json({ error: `Missing fields: ${missing.join(', ')}` });

  const { name, category, country, region, lat, lon, description } = req.body;
  const latNum = Number(lat), lonNum = Number(lon);
  if (Number.isNaN(latNum) || Number.isNaN(lonNum)) {
    return res.status(400).json({ error: 'Latitude and longitude must be numbers' });
  }

  const sql = `
    INSERT INTO healthcare_resources
    (name, category, country, region, lat, lon, description, recommendations)
    VALUES (?, ?, ?, ?, ?, ?, ?, 0)
  `;
  db.run(sql, [name, category, country, region, latNum, lonNum, description], function (err) {
    if (err) return res.status(500).json({ error: 'Database insert error' });
    return res.status(201).json({ message: 'Resource added', id: this.lastID });
  });
});

app.put('/api/resources/:id/recommend', requireLogin, (req, res) => {
  const id = req.params.id;
  db.run('UPDATE healthcare_resources SET recommendations = recommendations + 1 WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    db.get('SELECT recommendations FROM healthcare_resources WHERE id = ?', [id], (err2, row) => {
      if (err2) return res.status(500).json({ error: 'Fetch failed' });
      return res.json({ message: 'Recommendation added', recommendations: row?.recommendations ?? 0 });
    });
  });
});

// --- Reviews (rating + comment) ---
app.get('/api/resources/:id/reviews', (req, res) => {
  const id = req.params.id;
  db.all(`
    SELECT r.id, r.rating, r.comment, r.created_at, u.username
    FROM reviews r
    JOIN users u ON u.id = r.user_id
    WHERE r.resource_id = ?
    ORDER BY r.created_at DESC
    LIMIT 20
  `, [id], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

app.post('/api/resources/:id/reviews', requireLogin, (req, res) => {
  const resourceId = Number(req.params.id);
  const rating = Number.parseInt(req.body.rating, 10);
  const comment = String(req.body.comment || '').trim();

  if (!Number.isFinite(resourceId)) return res.status(400).json({ error: 'Bad resource id' });
  if (!Number.isFinite(rating) || rating < 1 || rating > 5) return res.status(400).json({ error: 'Rating must be 1–5' });
  if (!comment) return res.status(400).json({ error: 'Comment is required' });

  db.run(
    `INSERT INTO reviews (resource_id, user_id, rating, comment) VALUES (?, ?, ?, ?)`,
    [resourceId, req.session.user.id, rating, comment],
    function (err) {
      if (err) return res.status(500).json({ error: 'Insert failed' });

      db.get(
        `SELECT r.id, r.rating, r.comment, r.created_at, u.username
         FROM reviews r JOIN users u ON u.id = r.user_id
         WHERE r.id = ?`, [this.lastID],
        (err2, row) => {
          if (err2) return res.status(500).json({ error: 'Fetch failed' });
          res.status(201).json(row);
        }
      );
    }
  );
});

// --- Start server ---
const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
