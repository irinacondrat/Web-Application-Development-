// scripts/migrate-reviews.js
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./db/discoverhealth.db');

db.get(`SELECT rating FROM reviews LIMIT 1`, (err) => {
  if (!err) {
    console.log('Schema already has rating/comment. No migration needed.');
    process.exit(0);
  }
  console.log('Running migration from old "review" column → rating/comment…');

  db.serialize(() => {
    db.exec(`PRAGMA foreign_keys=OFF; BEGIN;`, (e) => {
      if (e) { console.error(e); process.exit(1); }

      db.exec(`
        ALTER TABLE reviews RENAME TO reviews_old;

        CREATE TABLE reviews (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          resource_id INTEGER NOT NULL,
          user_id INTEGER NOT NULL,
          rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
          comment TEXT NOT NULL CHECK(length(comment) <= 500),
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(resource_id) REFERENCES healthcare_resources(id) ON DELETE CASCADE,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );

        INSERT INTO reviews (resource_id, user_id, rating, comment, created_at)
        SELECT resource_id,
               user_id,
               5,
               review,
               CASE
                 WHEN typeof(created_at)='integer' THEN datetime(created_at,'unixepoch')
                 ELSE created_at
               END
        FROM reviews_old;

        DROP TABLE reviews_old;
        COMMIT;
        PRAGMA foreign_keys=ON;
      `, (err2) => {
        if (err2) {
          console.error('Migration failed:', err2.message);
          process.exit(1);
        }
        console.log('✅ Migration completed.');
        process.exit(0);
      });
    });
  });
});
