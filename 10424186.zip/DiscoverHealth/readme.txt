# DiscoverHealth

## Run
1. Node 20+ installed.
2. `npm install`
3. `npm start`
4. Open http://localhost:3000

## Structure
- app.js (Express server)
- /public
  - index.html, login.html, register.html, addResource.html (+ any CSS/JS)
- /db
  - discoverhealth.db

## Test quickly
- Search a region (e.g., London)
- Click markers, post a review (logged-in)
- Recommend a resource (logged-in)
- Add resource via map click (logged-in)

## Notes
- Sessions via express-session; logout at `/logout`.
